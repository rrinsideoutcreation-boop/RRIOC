import React from 'react';
import Hero from './components/Hero';
import WhyUs from './components/WhyUs';
import FloorPlans from './components/FloorPlans';
import Packages from './components/Packages';
import FreeServices from './components/FreeServices';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen">
      <Hero />
      <WhyUs />
      <FloorPlans />
      <Packages />
      <FreeServices />
      <Testimonials />
      <Contact />
      <Footer />
    </div>
  );
}

import { motion } from 'motion/react';
import { Check } from 'lucide-react';

const packages = [
  {
    name: "Rental Ready",
    subtitle: "For Investors & Rental Income Homes",
    image: "https://images.unsplash.com/photo-1556912172-45b7abe8b7e1?auto=format&fit=crop&q=80&w=1000",
    pricing: [
      { size: "2BHK", price: "₹4.49 Lakhs*" },
      { size: "3BHK", price: "₹6.99 Lakhs*" },
      { size: "4BHK", price: "₹9.49 Lakhs*" },
    ],
    features: [
      "Free Design Consultation",
      "Free 2D Layout Planning",
      "Free Basic 3D Design",
      "Modular Kitchen",
      "Wardrobes & TV Unit",
      "Electrical & Lighting",
      "Paint Work",
      "Washroom Vanity"
    ],
    usps: ["Fast Execution", "Rental Optimized", "Durable Materials", "Budget Friendly"]
  },
  {
    name: "Family Living",
    subtitle: "For Families Moving Into Their Dream Home",
    image: "https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=1000",
    isPopular: true,
    pricing: [
      { size: "2BHK", price: "₹8.99 Lakhs*" },
      { size: "3BHK", price: "₹12.99 Lakhs*" },
      { size: "4BHK", price: "₹16.99 Lakhs*" },
    ],
    features: [
      "Free Design Consultation",
      "Free Premium 3D Design",
      "Modular Kitchen",
      "Full Height Wardrobes",
      "Decorative False Ceiling",
      "Premium Lighting & Paint",
      "Crockery, Study & Shoe Units",
      "Branded Hardware"
    ],
    usps: ["Storage Focused", "Elegant Design", "Family Comfort", "Functional Living"]
  }
];

export default function Packages() {
  return (
    <section id="packages" className="py-24 bg-white relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-20">
          <h2 className="text-sm font-sans tracking-[0.2em] text-gold-600 uppercase mb-4">Curated Interiors</h2>
          <h3 className="text-4xl md:text-5xl font-serif text-obsidian-950 mb-6">
            Find the Perfect Package
          </h3>
          <p className="text-lg text-obsidian-800/70">
            From smart rental setups to bespoke luxury experiences, we have tailored interior configurations for every lifestyle.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {packages.map((pkg, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              className="group bg-pearl-50 border border-pearl-200 overflow-hidden flex flex-col relative"
            >
              {pkg.isPopular && (
                <div className="absolute top-4 right-4 z-10 bg-gold-500 text-obsidian-950 text-xs font-bold tracking-wider uppercase px-4 py-1">
                  Most Popular
                </div>
              )}
              
              <div className="aspect-[16/9] overflow-hidden relative">
                <img 
                  src={pkg.image} 
                  alt={pkg.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-obsidian-950/80 to-transparent" />
                <div className="absolute bottom-0 left-0 p-6 sm:p-8">
                  <h4 className="text-3xl font-serif text-white mb-2">{pkg.name}</h4>
                  <p className="text-pearl-200 font-light text-sm sm:text-base">{pkg.subtitle}</p>
                </div>
              </div>

              <div className="p-6 sm:p-8 flex-1 flex flex-col">
                <div className="grid grid-cols-3 gap-2 mb-8 bg-white p-4 border border-pearl-200 divide-x divide-pearl-200">
                  {pkg.pricing.map((p, i) => (
                    <div key={i} className="text-center px-1">
                      <div className="text-xs text-obsidian-800/60 uppercase tracking-widest mb-1">{p.size}</div>
                      <div className="font-serif font-medium text-gold-600 text-[15px] sm:text-lg whitespace-nowrap">{p.price}</div>
                    </div>
                  ))}
                </div>

                <div className="mb-8 flex-1">
                  <p className="text-xs uppercase tracking-widest text-obsidian-800/50 font-bold mb-4">What's Included</p>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-y-3 gap-x-6">
                    {pkg.features.map((feature, i) => (
                      <li key={i} className="flex items-start gap-3">
                        <Check className="w-4 h-4 text-gold-500 shrink-0 mt-0.5" />
                        <span className="text-sm text-obsidian-800/80 leading-tight">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-6 border-t border-pearl-200">
                   <div className="flex flex-wrap gap-2">
                    {pkg.usps.map((usp, i) => (
                      <span key={i} className="text-[11px] uppercase tracking-wider bg-white border border-pearl-200 text-obsidian-900 px-2 py-1">
                        {usp}
                      </span>
                    ))}
                   </div>
                </div>

                <div className="mt-8">
                  <a href="#contact" className="block w-full py-4 text-center border-2 border-obsidian-950 text-obsidian-950 font-medium hover:bg-obsidian-950 hover:text-white transition-colors">
                    Request Detailed Quote
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { motion } from 'motion/react';
import { PenTool, Map, LayoutDashboard, DraftingCompass, Cuboid, Calculator } from 'lucide-react';

const freebies = [
  { icon: PenTool, title: "Design Consultation" },
  { icon: Map, title: "Site Visit" },
  { icon: LayoutDashboard, title: "Space Planning" },
  { icon: DraftingCompass, title: "Basic 2D Layout" },
  { icon: Cuboid, title: "3D Visualization" },
  { icon: Calculator, title: "Budget Planning" },
];

export default function FreeServices() {
  return (
    <section className="py-24 bg-obsidian-950 text-white relative flex items-center overflow-hidden">
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-20"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1541888081622-c2ab0517fa49?auto=format&fit=crop&q=80&w=2000")',
        }}
      />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-16">
          <div className="lg:w-1/2 text-center lg:text-left">
            <h2 className="text-sm font-sans tracking-[0.2em] text-gold-500 uppercase mb-4">Unmatched Value</h2>
            <h3 className="text-4xl md:text-5xl font-serif mb-6">
              Included Free With Every Consultation
            </h3>
            <p className="text-pearl-200 text-lg md:text-xl font-light mb-8 max-w-2xl mx-auto lg:mx-0">
              We believe in showing our value before you commit. Our experts provide a complete preliminary design and budget roadmap at zero cost.
            </p>
            <a href="#contact" className="inline-flex items-center justify-center px-8 py-4 bg-gold-500 text-obsidian-950 font-medium transition-all hover:bg-gold-400">
              Claim Free Consultation
            </a>
          </div>

          <div className="lg:w-1/2 w-full">
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 md:gap-6">
              {freebies.map((item, idx) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={idx}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true, margin: "-50px" }}
                    transition={{ duration: 0.4, delay: idx * 0.1 }}
                    className="flex flex-col items-center justify-center text-center p-6 bg-obsidian-900/50 backdrop-blur-sm border border-obsidian-800 hover:border-gold-500/50 transition-colors"
                  >
                    <Icon className="w-8 h-8 text-gold-400 mb-4" strokeWidth={1.5} />
                    <span className="text-sm font-medium text-pearl-100">{item.title}</span>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

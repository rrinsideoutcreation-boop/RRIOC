export default function Footer() {
  return (
    <footer className="bg-obsidian-950 text-pearl-200 py-12 border-t border-white/10">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-xl font-serif text-white mb-4">RR Inside Out Creation Pvt. Ltd.</h2>
        <p className="text-sm text-pearl-200/50 mb-8 max-w-md mx-auto">
          Configuration + Lifestyle Based Packages across Gurgaon. Creating beautiful, functional, and valuable spaces.
        </p>
        <div className="flex flex-wrap justify-center gap-6 text-sm text-pearl-200/70 mb-8">
          <a href="#about" className="hover:text-gold-400 transition-colors">Why Us</a>
          <a href="#packages" className="hover:text-gold-400 transition-colors">Packages</a>
          <a href="#contact" className="hover:text-gold-400 transition-colors">Contact</a>
        </div>
        <p className="text-xs text-pearl-200/30">
          &copy; {new Date().getFullYear()} RR Inside Out Creation Pvt. Ltd. All rights reserved.
        </p>
      </div>
    </footer>
  );
}

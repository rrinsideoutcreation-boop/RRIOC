import { motion } from 'motion/react';
import React, { useState, useEffect } from 'react';
import { Send, MapPin, Phone, Mail, Settings } from 'lucide-react';
import { initAuth, googleSignIn, getAccessToken, logout } from '../lib/auth';
import type { User } from 'firebase/auth';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    package: '',
    unit: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  
  const [needsAuth, setNeedsAuth] = useState(true);
  const [user, setUser] = useState<User | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);
  const [spreadsheetId, setSpreadsheetId] = useState(() => localStorage.getItem('crm_spreadsheet_id') || '');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.id]: e.target.value
    }));
  };

  useEffect(() => {
    const unsubscribe = initAuth(
      (user, token) => {
        setUser(user);
        setNeedsAuth(false);
      },
      () => {
        setUser(null);
        setNeedsAuth(true);
      }
    );
    return () => unsubscribe();
  }, []);

  const handleLogin = async () => {
    setIsLoggingIn(true);
    try {
      const result = await googleSignIn();
      if (result) {
        setUser(result.user);
        setNeedsAuth(false);
      }
    } catch (err) {
      console.error('Login failed:', err);
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleAdminSave = () => {
    localStorage.setItem('crm_spreadsheet_id', spreadsheetId);
    setShowAdmin(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!needsAuth && spreadsheetId) {
      const confirmed = window.confirm(
        `Are you sure you want to submit this form and append your information to the Google Sheet?`
      );
      if (!confirmed) return;
      
      setIsSubmitting(true);
      try {
        const accessToken = await getAccessToken();
        const range = 'Sheet1!A1:E1'; 
        
        // Data row to append
        const rowData = [
          new Date().toISOString(),
          formData.name,
          formData.phone,
          formData.package || 'Not chosen',
          formData.unit || 'Not chosen',
          formData.message || 'No message'
        ];

        const response = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${range}:append?valueInputOption=USER_ENTERED`, {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({
            values: [rowData]
          })
        });

        if (!response.ok) {
          throw new Error('Failed to append to spreadsheet. Ensure it is shared as "Anyone with the link can edit".');
        }

        setIsSubmitting(false);
        setIsSubmitted(true);
      } catch (error) {
        console.error("Error saving to sheet:", error);
        alert('There was an error saving your data: ' + (error instanceof Error ? error.message : 'Unknown error'));
        setIsSubmitting(false);
      }
    } else {
      // Fallback to WhatsApp and Email if Google Sheets is not configured or user not logged in
      setIsSubmitting(true);
      
      const phoneNumber = "918005987790"; 
      const email = "rrinsideoutcreation@gmail.com";
      const subject = "Free Consultation Enquiry";
      const text = `Hello RR Inside Out Creation! I am interested in a free consultation. Here are my details:

*Name:* ${formData.name}
*Phone:* ${formData.phone}
*Interested Package:* ${formData.package || 'Not chosen'}
*Unit Configuration:* ${formData.unit || 'Not chosen'}

*Message:* ${formData.message || 'No additional message.'}`;

      const whatsappUrl = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(text)}`;
      const mailtoUrl = `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;

      setTimeout(() => {
        setIsSubmitting(false);
        setIsSubmitted(true);
        window.open(whatsappUrl, '_blank');
        window.location.href = mailtoUrl;
      }, 800);
    }
  };

  return (
    <section id="contact" className="py-24 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto flex flex-col lg:flex-row gap-16">
          <div className="lg:w-1/3">
            <h2 className="text-sm font-sans tracking-[0.2em] text-gold-600 uppercase mb-4">Get In Touch</h2>
            <h3 className="text-4xl font-serif text-obsidian-950 mb-6">
              Start Your Journey
            </h3>
            <p className="text-obsidian-800/70 mb-10 leading-relaxed">
              Book your free design consultation today. Let our experts plan your space and budget with zero commitments.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 flex items-center justify-center bg-pearl-50 text-gold-600 shrink-0">
                  <Phone className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-sm font-bold text-obsidian-900 uppercase tracking-wider mb-1">Call Us</p>
                  <p className="text-obsidian-800/70">+91 7701996418<br/>+91 8005987790<br/>+91 8619222683</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 flex items-center justify-center bg-pearl-50 text-gold-600 shrink-0">
                  <Mail className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-sm font-bold text-obsidian-900 uppercase tracking-wider mb-1">Email</p>
                  <p className="text-obsidian-800/70">rrinsideoutcreation@gmail.com</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 flex items-center justify-center bg-pearl-50 text-gold-600 shrink-0">
                  <MapPin className="w-4 h-4" />
                </div>
                <div>
                  <p className="text-sm font-bold text-obsidian-900 uppercase tracking-wider mb-1">Location</p>
                  <p className="text-obsidian-800/70">Gurugram / Delhi NCR</p>
                  <p className="text-xs text-obsidian-800/50 mt-1">GST: 06AANCR5273J1ZW</p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:w-2/3">
            <div className="bg-pearl-50 p-8 sm:p-12 border border-pearl-200 relative">
              <button 
                onClick={() => setShowAdmin(!showAdmin)}
                className="absolute top-4 right-4 text-obsidian-800/40 hover:text-gold-600 transition-colors"
                title="Admin Settings"
              >
                <Settings className="w-5 h-5" />
              </button>

              {showAdmin && (
                <div className="mb-8 p-6 bg-white border border-gold-200">
                  <h4 className="text-sm font-bold text-obsidian-900 uppercase tracking-wider mb-4">Google Sheets Integration</h4>
                  <div className="space-y-4">
                    <div>
                      <label htmlFor="spreadsheetId" className="block text-xs font-bold text-obsidian-800 uppercase mb-2">Spreadsheet ID</label>
                      <input 
                        type="text" 
                        id="spreadsheetId" 
                        value={spreadsheetId}
                        onChange={(e) => setSpreadsheetId(e.target.value)}
                        placeholder="e.g. 1BxiMVs0XRA5nFMdKvBdBZjgmUUqptlbs74OgvE2upms"
                        className="w-full bg-pearl-50 border border-pearl-200 px-4 py-2 text-sm focus:outline-none focus:border-gold-500"
                      />
                      <p className="text-xs text-obsidian-800/60 mt-2">To allow visitors to write to this sheet, it must be shared as "Anyone with the link can edit". It should have a tab named "Sheet1".</p>
                    </div>
                    <button 
                      onClick={handleAdminSave}
                      className="px-4 py-2 bg-obsidian-900 text-white text-sm hover:bg-gold-600 transition-colors"
                    >
                      Save Configuration
                    </button>
                  </div>
                </div>
              )}

              {isSubmitted ? (
                <motion.div 
                  initial={{ opacity: 0 }} 
                  animate={{ opacity: 1 }}
                  className="text-center py-16"
                >
                  <div className="w-16 h-16 bg-gold-50 text-gold-600 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Send className="w-6 h-6" />
                  </div>
                  <h4 className="text-2xl font-serif text-obsidian-950 mb-2">Request Received</h4>
                  <p className="text-obsidian-800/70">Thank you! Our design expert will contact you shortly to schedule your free consultation.</p>
                </motion.div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="name" className="text-xs font-bold text-obsidian-900 uppercase tracking-wider">Full Name</label>
                      <input 
                        type="text" 
                        id="name" 
                        required
                        value={formData.name}
                        onChange={handleChange}
                        className="w-full bg-white border border-pearl-200 px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-colors text-obsidian-900"
                        placeholder="John Doe"
                      />
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="phone" className="text-xs font-bold text-obsidian-900 uppercase tracking-wider">Phone Number</label>
                      <input 
                        type="tel" 
                        id="phone" 
                        required
                        value={formData.phone}
                        onChange={handleChange}
                        className="w-full bg-white border border-pearl-200 px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-colors text-obsidian-900"
                        placeholder="+91 98765 43210"
                      />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label htmlFor="package" className="text-xs font-bold text-obsidian-900 uppercase tracking-wider">Interested Package</label>
                      <select 
                        id="package"
                        value={formData.package}
                        onChange={handleChange}
                        className="w-full bg-white border border-pearl-200 px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-colors text-obsidian-900"
                      >
                        <option value="">Select a package...</option>
                        <option value="rental">Rental Ready</option>
                        <option value="family">Family Living</option>
                        <option value="unsure">Not Sure / Need Advice</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="unit" className="text-xs font-bold text-obsidian-900 uppercase tracking-wider">Godrej Air Unit (Optional)</label>
                      <select 
                        id="unit"
                        value={formData.unit}
                        onChange={handleChange}
                        className="w-full bg-white border border-pearl-200 px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-colors text-obsidian-900"
                      >
                        <option value="">Select Godrej Air Unit...</option>
                        <option value="1bhk">Tower A5 - 1 BHK</option>
                        <option value="2bhk">Tower A1 to A5 - 2 BHK</option>
                        <option value="3bhk">Tower A1 to A5 - 3 BHK</option>
                        <option value="4bhk">Tower A2/A4 - 4 BHK</option>
                        <option value="other">Other Project Unit...</option>
                      </select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="message" className="text-xs font-bold text-obsidian-900 uppercase tracking-wider">Message</label>
                    <textarea 
                      id="message" 
                      rows={4}
                      value={formData.message}
                      onChange={handleChange}
                      className="w-full bg-white border border-pearl-200 px-4 py-3 focus:outline-none focus:border-gold-500 focus:ring-1 focus:ring-gold-500 transition-colors text-obsidian-900 resize-none"
                      placeholder="Tell us about your property and requirements..."
                    ></textarea>
                  </div>

                  {needsAuth && spreadsheetId && (
                    <div className="p-4 bg-white border border-pearl-200 flex flex-col sm:flex-row items-center gap-4 justify-between">
                      <p className="text-sm text-obsidian-800">Please sign in to submit to Google Sheets</p>
                      <button 
                        type="button"
                        onClick={handleLogin}
                        disabled={isLoggingIn}
                        className="gsi-material-button w-full sm:w-auto p-2"
                        style={{ border: '1px solid #ccc', borderRadius: '4px', background: 'white' }}
                      >
                        <div className="gsi-material-button-state"></div>
                        <div className="gsi-material-button-content-wrapper flex items-center gap-3 px-2">
                          <div className="gsi-material-button-icon">
                            <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" className="w-5 h-5 block">
                              <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"></path>
                              <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"></path>
                              <path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"></path>
                              <path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"></path>
                              <path fill="none" d="M0 0h48v48H0z"></path>
                            </svg>
                          </div>
                          <span className="gsi-material-button-contents text-sm font-medium text-gray-700">Sign in with Google</span>
                        </div>
                      </button>
                    </div>
                  )}
                  {!needsAuth && user && (
                    <div className="flex items-center justify-between p-3 bg-white border border-pearl-200">
                      <p className="text-sm text-green-700">Signed in as {user.email}</p>
                      <button type="button" onClick={logout} className="text-xs text-red-600 hover:underline">Sign out</button>
                    </div>
                  )}

                  <button 
                    type="submit" 
                    disabled={isSubmitting || (!!spreadsheetId && needsAuth)}
                    className="w-full py-4 bg-obsidian-950 text-white font-medium hover:bg-gold-500 transition-colors flex items-center justify-center gap-2 disabled:opacity-70 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? 'Sending...' : (spreadsheetId ? 'Submit to Google Sheets' : 'Request Free Consultation')} <Send className="w-4 h-4 mt-0.5" />
                  </button>

                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

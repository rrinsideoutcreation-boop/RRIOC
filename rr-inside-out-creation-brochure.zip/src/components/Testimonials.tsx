import { motion } from 'motion/react';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    text: "The Rental Ready package completely transformed our 3BHK in Gurgaon. We rented it out within a week of completion at a premium rate.",
    author: "Amit S.",
    role: "NRI Investor"
  },
  {
    text: "We chose the Family Living package. The design process was seamless, and the storage solutions they provided were exactly what we needed with two kids.",
    author: "Priya & Rahul",
    role: "Homeowners"
  },
  {
    text: "RR Inside Out brought luxury and sophistication to our penthouse. The execution was flawless, matching their 3D designs perfectly.",
    author: "Vikram R.",
    role: "Premium Homeowner"
  }
];

export default function Testimonials() {
  return (
    <section className="py-24 bg-pearl-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-sm font-sans tracking-[0.2em] text-gold-600 uppercase mb-4">Client Stories</h2>
          <h3 className="text-4xl md:text-5xl font-serif text-obsidian-950">
            Trusted by Gurgaon Homeowners
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((test, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.2 }}
              className="bg-white p-8 border border-pearl-200 relative mt-8 pt-12"
            >
              <div className="absolute -top-6 left-8 w-12 h-12 bg-gold-500 text-obsidian-950 flex items-center justify-center">
                <Quote className="w-5 h-5 fill-current" />
              </div>
              <p className="text-obsidian-800/80 leading-relaxed mb-8 italic">
                "{test.text}"
              </p>
              <div>
                <p className="font-serif text-xl text-obsidian-950">{test.author}</p>
                <p className="text-xs uppercase tracking-wider text-gold-600 font-bold mt-1">{test.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

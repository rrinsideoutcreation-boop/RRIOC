import { motion, AnimatePresence } from 'motion/react';
import React, { useState } from 'react';
import { Home, IndianRupee, MapPin } from 'lucide-react';

const floorPlanConfigs = [
  {
    id: '1bhk',
    title: '1 BHK',
    description: 'Perfect for working professionals or young couples.',
    subUnits: [
      {
        name: 'Standard',
        tower: 'Tower A5',
        area: '954-955 sq. ft. (Super built-up)',
        details: '1 bedroom, living/dining, kitchen, bathroom, balcony.',
        image: 'https://images.unsplash.com/photo-1593696140826-c58b021acf8b?auto=format&fit=crop&q=80&w=1200',
      }
    ]
  },
  {
    id: '2bhk',
    title: '2 BHK',
    description: 'Ideal for small families seeking modern comfort.',
    subUnits: [
      {
        name: 'Optima / Type 1',
        tower: 'Tower A3',
        area: '678 sq. ft. (Carpet)',
        details: '2 bedrooms, 2 bathrooms, living room, kitchen, balcony.',
        image: 'https://images.unsplash.com/photo-1598928506311-c95d43b271d1?auto=format&fit=crop&q=80&w=1200',
      },
      {
        name: 'Ultima / Type 2',
        tower: 'Tower A5',
        area: '826 sq. ft. (Carpet)',
        details: '2 bedrooms, 2 bathrooms, living room, kitchen, balcony.',
        image: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&q=80&w=1200',
      },
      {
        name: 'Ultima Large',
        tower: 'Tower A3 or A5',
        area: '902 sq. ft. (Carpet)',
        details: '2 bedrooms, 2 bathrooms, living room, kitchen, balcony.',
        image: 'https://images.unsplash.com/photo-1600607687920-4e2a09cf159d?auto=format&fit=crop&q=80&w=1200',
      },
      {
        name: 'Standard',
        tower: 'Tower A3 or A5',
        area: '990.28 sq. ft. (Super built-up)',
        details: '2 bedrooms, living/dining, kitchen, bathrooms, balcony.',
        image: 'https://images.unsplash.com/photo-1600607687644-aac4c1566f55?auto=format&fit=crop&q=80&w=1200',
      }
    ]
  },
  {
    id: '3bhk',
    title: '3 BHK',
    description: 'Spacious layouts designed for growing families.',
    subUnits: [
      {
        name: 'Optima / Type 1',
        tower: 'Tower A1',
        area: '1092 sq. ft. (Carpet)',
        details: '3 bedrooms, 3 bathrooms, living room, kitchen, balcony.',
        image: 'https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?auto=format&fit=crop&q=80&w=1200',
      },
      {
        name: 'Ultima',
        tower: 'Tower A1 or A5',
        area: '1358 sq. ft. (Carpet)',
        details: '3 bedrooms, 3 bathrooms, living room, kitchen, balcony.',
        image: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?auto=format&fit=crop&q=80&w=1200',
      },
      {
        name: 'Ultima Large / Type 2',
        tower: 'Tower A5',
        area: '1470 sq. ft. (Carpet)',
        details: '3 bedrooms, 3 bathrooms, living room, kitchen, balcony.',
        image: 'https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?auto=format&fit=crop&q=80&w=1200',
      },
      {
        name: 'Standard Range',
        tower: 'Tower A1, A2, A4, or A5',
        area: '1291.67-2129 sq. ft. (Super built-up)',
        details: 'Living/dining, kitchen, 3 bedrooms, bathrooms; utility in some variants.',
        image: 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&q=80&w=1200',
      }
    ]
  },
  {
    id: '4bhk',
    title: '4 BHK',
    description: 'Expansive luxury living with premium finishes.',
    subUnits: [
      {
        name: 'Ultima',
        tower: 'Tower A2 or A4',
        area: '1976 sq. ft. (Carpet)',
        details: '4 bedrooms, 4 bathrooms, living room, kitchen, balcony.',
        image: 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&q=80&w=1200',
      },
      {
        name: 'Ultima Large',
        tower: 'Tower A2 or A4',
        area: '2092 sq. ft. (Carpet)',
        details: '4 bedrooms, 4 bathrooms, living room, kitchen, balcony.',
        image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=1200',
      },
      {
        name: 'Standard Range',
        tower: 'Tower A2 or A4',
        area: '1840.63-2599 sq. ft. (Super built-up)',
        details: '4 bedrooms, bathrooms, living/dining, kitchen; utility in larger variants.',
        image: 'https://images.unsplash.com/photo-1600607686527-6fb886090705?auto=format&fit=crop&q=80&w=1200',
      }
    ]
  }
];

export default function FloorPlans() {
  const [activeConfig, setActiveConfig] = useState(floorPlanConfigs[0]);
  const [activeSubunitIndex, setActiveSubunitIndex] = useState(0);

  const activeSubUnit = activeConfig.subUnits[activeSubunitIndex] || activeConfig.subUnits[0];

  return (
    <section id="floorplans" className="py-24 bg-obsidian-950 text-white relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-obsidian-900 border border-obsidian-800 rounded-full text-gold-500 text-xs font-sans tracking-[0.2em] uppercase mb-6">
            <MapPin className="w-3 h-3" /> Godrej Air, Sector 84, Gurugram
          </div>
          <h3 className="text-4xl md:text-5xl font-serif mb-6">
            Site-Specific Floor Plans
          </h3>
          <p className="text-pearl-200 text-lg font-light max-w-2xl mx-auto">
            Choose your configuration to see the exact layouts available for Godrej Air units and seamlessly pair them with our personalized interior packages.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-12 items-start">
          <div className="w-full lg:w-1/3 flex flex-col gap-4">
            {floorPlanConfigs.map((config) => (
              <button
                key={config.id}
                onClick={() => {
                  setActiveConfig(config);
                  setActiveSubunitIndex(0);
                }}
                className={`p-6 text-left border transition-all ${
                  activeConfig.id === config.id 
                    ? 'bg-gold-500 border-gold-500 text-obsidian-950 shadow-[0_0_20px_rgba(212,175,55,0.15)]' 
                    : 'bg-transparent border-obsidian-800 text-pearl-100 hover:border-gold-500/50'
                }`}
              >
                <div className="flex justify-between items-center mb-2">
                  <h4 className="text-xl font-serif font-bold">{config.title}</h4>
                  <Home className={`w-5 h-5 ${activeConfig.id === config.id ? 'text-obsidian-950' : 'text-gold-500'}`} />
                </div>
                <p className={`text-sm ${activeConfig.id === config.id ? 'text-obsidian-900' : 'text-pearl-200/70'}`}>
                  {config.subUnits.length} Models Available
                </p>
              </button>
            ))}
          </div>

          <div className="w-full lg:w-2/3">
            <div className="flex flex-wrap gap-2 mb-4">
              {activeConfig.subUnits.map((subUnit, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveSubunitIndex(idx)}
                  className={`px-4 py-2 text-sm border transition-colors ${
                    activeSubunitIndex === idx 
                      ? 'bg-white text-obsidian-950 border-white font-medium' 
                      : 'bg-transparent text-pearl-200 border-obsidian-800 hover:border-pearl-200'
                  }`}
                >
                  {subUnit.name}
                </button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={`${activeConfig.id}-${activeSubunitIndex}`}
                initial={{ opacity: 0, scale: 0.98 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.02 }}
                transition={{ duration: 0.4 }}
                className="bg-obsidian-900 border border-obsidian-800 p-2"
              >
                <div className="aspect-[4/3] bg-obsidian-950 relative overflow-hidden flex items-center justify-center group">
                  <img 
                    src={activeSubUnit.image} 
                    alt={`${activeSubUnit.name} Floor Plan`}
                    className="w-full h-full object-cover opacity-60 transition-opacity duration-700 group-hover:opacity-80"
                  />
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-obsidian-950 via-obsidian-950/80 to-transparent p-6 pt-32 text-center">
                    <h5 className="text-2xl font-serif text-white mb-2">{activeSubUnit.name}</h5>
                    <div className="flex flex-col items-center justify-center gap-2 text-sm mt-3">
                      <div className="flex flex-wrap items-center justify-center gap-2">
                        <span className="px-3 py-1 bg-white/10 rounded-full border border-white/10 text-pearl-100">
                          {activeSubUnit.tower}
                        </span>
                        <span className="px-3 py-1 bg-white/10 rounded-full border border-white/10 text-pearl-100">
                          {activeSubUnit.area}
                        </span>
                      </div>
                      <p className="text-pearl-200/80 text-xs max-w-lg mt-2">
                        {activeSubUnit.details}
                      </p>
                    </div>
                    
                    <p className="text-[10px] text-gold-500 mt-6 tracking-widest uppercase opacity-70">
                      * User floorplan visual placeholder. Direct CRM sync applied.
                    </p>
                  </div>
                </div>
                
                <div className="p-6 md:p-8 bg-obsidian-900 mt-2 border-t border-obsidian-800 flex flex-col sm:flex-row items-center justify-between gap-6">
                  <div>
                    <h4 className="text-lg font-medium text-white mb-1">Pair with a Budget Plan</h4>
                    <p className="text-sm text-pearl-200/70">Our packages scale perfectly with the specific layout of {activeSubUnit.name}.</p>
                  </div>
                  <a 
                    href={`#packages`}
                    className="inline-flex items-center gap-2 px-6 py-3 bg-white text-obsidian-950 font-medium hover:bg-gold-500 transition-colors whitespace-nowrap lg:shrink-0"
                  >
                    <IndianRupee className="w-4 h-4" /> View Pricing for {activeConfig.title}
                  </a>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
      </div>
    </section>
  );
}

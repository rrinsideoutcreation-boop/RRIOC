import { motion } from 'motion/react';
import { Clock, Tag, TrendingUp, MessageCircle, ShieldCheck } from 'lucide-react';

const reasons = [
  { icon: Clock, title: 'Faster Decision Making', description: 'Streamlined choices perfectly suited for your configuration.' },
  { icon: Tag, title: 'Easier Pricing', description: 'Transparent and predictable costs with zero hidden charges.' },
  { icon: TrendingUp, title: 'Better Ad Conversion', description: 'Optimized packages that resonate with rental markets.' },
  { icon: MessageCircle, title: 'Easier WhatsApp Selling', description: 'Clear PDFs and layouts ready to share with stakeholders.' },
  { icon: ShieldCheck, title: 'Higher Trust', description: 'End-to-end execution backed by our quality guarantee.' },
];

export default function WhyUs() {
  return (
    <section id="about" className="py-24 bg-pearl-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-sm font-sans tracking-[0.2em] text-gold-600 uppercase mb-4">Why Choose Us</h2>
          <h3 className="text-4xl md:text-5xl font-serif text-obsidian-950">
            The Smart Way to<br/>Design Your Space
          </h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-8">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-50px" }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="flex flex-col items-center text-center p-6 bg-white border border-pearl-200 hover:border-gold-400 transition-colors"
              >
                <div className="w-12 h-12 flex items-center justify-center bg-gold-50 text-gold-600 rounded-full mb-6">
                  <Icon className="w-6 h-6" strokeWidth={1.5} />
                </div>
                <h4 className="text-lg font-medium text-obsidian-900 mb-3">{reason.title}</h4>
                <p className="text-sm text-obsidian-800/70 leading-relaxed">
                  {reason.description}
                </p>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

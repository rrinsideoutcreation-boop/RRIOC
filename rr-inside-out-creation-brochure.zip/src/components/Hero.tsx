import { motion } from 'motion/react';
import { ArrowRight, ChevronDown } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-obsidian-950 text-white">
      {/* Background Image Overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center bg-no-repeat opacity-40 mix-blend-overlay"
        style={{ 
          backgroundImage: 'url("https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?auto=format&fit=crop&q=80&w=2000")',
        }}
      />
      
      {/* Gradient Vignette Top & Bottom */}
      <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-obsidian-950 to-transparent z-10" />
      <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-obsidian-950 to-transparent z-10" />

      <div className="relative z-20 container mx-auto px-6 px-4 sm:px-6 lg:px-8 text-center mt-16">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: "easeOut" }}
          className="max-w-4xl mx-auto space-y-8"
        >
          <div className="inline-block">
             <h2 className="text-[37px] font-sans tracking-[0.1em] text-gold-500 uppercase mb-4 leading-tight">
              RR Inside Out Creation Pvt. Ltd.
            </h2>
            <p className="text-xs tracking-widest text-pearl-200/60 uppercase mb-4">"Where Vision Meets Reality"</p>
            <div className="h-px w-full bg-gradient-to-r from-transparent via-gold-500 to-transparent opacity-50" />
          </div>
          
          <h1 className="text-[55px] font-serif leading-tight">
             Complete Turnkey Interiors for <span className="text-[77px] text-transparent bg-clip-text bg-gradient-to-r from-gold-400 to-gold-600 block mt-2">Godrej Air, Sector 85</span>
          </h1>

          <p className="text-xl md:text-2xl text-pearl-100 font-light max-w-2xl mx-auto leading-relaxed">
            Exclusive layout-specific interior packages for homeowners and investors at Godrej Air, Gurugram.
          </p>

          <div className="pt-8 flex flex-col sm:flex-row items-center justify-center gap-6">
            <a 
              href="#packages"
              className="group relative inline-flex items-center justify-center px-8 py-4 bg-gold-500 text-obsidian-950 font-medium transition-all hover:bg-gold-400 overflow-hidden"
            >
              <span className="relative z-10 flex items-center gap-2">
                Explore Packages <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1" />
              </span>
            </a>
            
            <a 
              href="#contact"
              className="inline-flex items-center justify-center px-8 py-4 border border-pearl-200/20 text-pearl-100 font-medium transition-all hover:bg-white/5 hover:border-gold-500/50"
            >
              Book Free Consultation
            </a>
          </div>
        </motion.div>
      </div>

      <motion.div 
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20"
        animate={{ y: [0, 10, 0] }}
        transition={{ repeat: Infinity, duration: 2, ease: "easeInOut" }}
      >
        <a href="#about" className="text-pearl-200/50 hover:text-gold-500 transition-colors">
          <ChevronDown className="w-8 h-8" />
        </a>
      </motion.div>
    </section>
  );
}
